import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class OpenFile {


    public void opening() {

        JFileChooser jFileChooserOpen =new JFileChooser();
        MainFrame mainFrame = new MainFrame();

        FileNameExtensionFilter filter = new FileNameExtensionFilter("Files","txt");
        jFileChooserOpen.addChoosableFileFilter(filter);
        int resultOpen = jFileChooserOpen.showOpenDialog(null);

            switch (resultOpen) {
                case JFileChooser.APPROVE_OPTION:
                    File file = jFileChooserOpen.getSelectedFile();

                    try
                    {
                        FileReader reader = new FileReader( file );
                        BufferedReader IN = new BufferedReader(reader);
                        mainFrame.jTextArea.read( IN, null );

                        IN.close();
                        mainFrame.jTextArea.requestFocus();
                        JOptionPane.showMessageDialog(null, "Data loaded successfully");
                    }
                    catch(IOException X) {
                        JOptionPane.showMessageDialog(null, "Data loaded ERROR");
                    }

                    break;
                case JFileChooser.CANCEL_OPTION:
                    JOptionPane.showMessageDialog(null, "Data load CANCELED");
                    break;
                case JFileChooser.ERROR_OPTION:
                    JOptionPane.showMessageDialog(null, "Data loaded ERROR");
                    break;


        }

    }
}
