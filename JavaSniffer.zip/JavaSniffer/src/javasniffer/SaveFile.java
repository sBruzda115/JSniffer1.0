import javax.swing.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class SaveFile {
    String data;

    SaveFile(String data) {
        this.data = data;

        }

        public void saving() {
            JFileChooser jFileChooserSave = new JFileChooser();

            int resultSave = jFileChooserSave.showSaveDialog(null);

            switch (resultSave) {
                case JFileChooser.APPROVE_OPTION:

                    try {
                        File DATA = new File(jFileChooserSave.getSelectedFile() + ".txt");
                        FileOutputStream fileOutputStream = new FileOutputStream(DATA);
                        PrintStream OUT = new PrintStream(fileOutputStream);

                        OUT.println(this.data);
                        OUT.close();

                        fileOutputStream.close();
                        JOptionPane.showMessageDialog(null, "Data saved successfully");
                    } catch (Exception X) {
                        JOptionPane.showMessageDialog(null, "Data saving ERROR,");

                    }

                    break;
                case JFileChooser.CANCEL_OPTION:
                    JOptionPane.showMessageDialog(null, "Data save CANCELED");
                    break;
                case JFileChooser.ERROR_OPTION:
                    JOptionPane.showMessageDialog(null, "Data saving ERROR");
                    break;
            }
        }

    }



