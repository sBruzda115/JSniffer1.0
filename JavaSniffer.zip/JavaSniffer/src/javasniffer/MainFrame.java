import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.NetworkInterface;
import jpcap.*;



public class MainFrame extends JFrame {
    JFrame jFrame = new JFrame();
    JButton buttonPlay = new JButton();
    JButton buttonStop = new JButton();
    JButton buttonClean = new JButton();
    JButton buttonInterfaces = new JButton();
    JButton buttonSaveFile = new JButton();
    JButton buttonOpenFile = new JButton();
    JTextArea jTextArea = new JTextArea();
    JScrollPane jScrollPane = new JScrollPane(jTextArea);
    NetworkInterface[] NETWORK_INTERFACE;
    JpcapCaptor CAP;
    






    MainFrame() {

        jFrame.add(buttonPlay);
        jFrame.add(buttonStop);
        jFrame.add(buttonClean);
        jFrame.add(buttonInterfaces);
        jFrame.add(buttonSaveFile);
        jFrame.add(buttonOpenFile);
        jFrame.add(jScrollPane);

//Frame_________________________________________________________________________________________________________________
         
        jFrame.setSize(1000, 700);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setVisible(true);
        jFrame.setTitle("Sniffer 1.0");
        jFrame.setLocationRelativeTo(null);
        jFrame.setResizable(false);
        jFrame.getContentPane().setBackground(new Color(0x67676C));
        jFrame.setLayout(null);
       // ImageIcon icon = new ImageIcon("dog-nose.ico");
        //jFrame.setIconImage(icon.getImage());

//JTextAre__&__JScrollPanel_____________________________________________________________________________________________

        //jTextArea.setEnabled(false);
        jTextArea.setLineWrap(true);
        jTextArea.setFont(new Font("Arial", Font.ITALIC, 20));
        jTextArea.setBackground(new Color(0xBFC7CC));
        

        jScrollPane.setBounds(15,15,852,525);
        jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

//buttonPlay____________________________________________________________________________________________________________

       // ImageIcon iconPlay = new ImageIcon("play-circle.png");
        buttonPlay.setBounds(702, 555, 285, 105);
        buttonPlay.setText("START");
        //buttonPlay.setIcon(iconPlay);
        buttonPlay.setHorizontalTextPosition(buttonPlay.CENTER);
        buttonPlay.setVerticalTextPosition(buttonPlay.BOTTOM);
        buttonPlay.setFont(new Font("Arial", Font.BOLD, 20));
        buttonPlay.setFocusable(false);
        buttonPlay.setBackground(new Color(0x007D1B));
        //buttonPlay.setBorder(new LineBorder(Color.BLACK));
        buttonPlay.setOpaque(true);
        buttonPlay.setBorderPainted(false);
        buttonPlay.setToolTipText("Start Sniffing");

//buttonStop____________________________________________________________________________________________________________

        //ImageIcon iconStop = new ImageIcon("pause-circle.png");
        buttonStop.setBounds(552, 555, 135, 105);
        buttonStop.setText("Stop");
        //buttonStop.setIcon(iconStop);
        buttonStop.setHorizontalTextPosition(buttonStop.CENTER);
        buttonStop.setVerticalTextPosition(buttonStop.BOTTOM);
        buttonStop.setFont(new Font("Arial", Font.BOLD, 20));
        buttonStop.setFocusable(false);
        buttonStop.setBackground(new Color(0xA10014));
        buttonStop.setOpaque(true);
        buttonStop.setBorderPainted(false);
        buttonStop.setToolTipText("Stop Sniffing");

//buttonInterfaces______________________________________________________________________________________________________

        //ImageIcon iconInterfaces = new ImageIcon("globe.png");
        buttonInterfaces.setBounds(402, 555, 135, 105);
        buttonInterfaces.setText("Interfaces");
        //buttonInterfaces.setIcon(iconInterfaces);
        buttonInterfaces.setHorizontalTextPosition(buttonInterfaces.CENTER);
        buttonInterfaces.setVerticalTextPosition(buttonInterfaces.BOTTOM);
        buttonInterfaces.setFont(new Font("Arial", Font.BOLD, 20));
        buttonInterfaces.setFocusable(false);
        buttonInterfaces.setBackground(new Color(0x013DD3));
        buttonInterfaces.setOpaque(true);
        buttonInterfaces.setBorderPainted(false);
        buttonInterfaces.setToolTipText("List Web Interfaces");

//buttonClean___________________________________________________________________________________________________________

        //ImageIcon iconClean = new ImageIcon("magic-wand.png");
        buttonClean.setBounds(252, 555, 135, 105);
        buttonClean.setText("Clean");
        //buttonClean.setIcon(iconClean);
        buttonClean.setHorizontalTextPosition(buttonClean.CENTER);
        buttonClean.setVerticalTextPosition(buttonClean.BOTTOM);
        buttonClean.setFont(new Font("Arial", Font.BOLD, 20));
        buttonClean.setFocusable(false);
        buttonClean.setBackground(new Color(0x9BA0AA));
        buttonClean.setOpaque(true);
        buttonClean.setBorderPainted(false);
        buttonClean.setToolTipText("Clean Text Area");

//buttonSaveFile____________________________________________________________________________________________________

       // ImageIcon DownloadFile = new ImageIcon("file-download.png");
        buttonSaveFile.setBounds(882, 15, 105, 255);
       // buttonSaveFile.setIcon(DownloadFile);
        buttonSaveFile.setText("Save\nFile");
        buttonSaveFile.setFont(new Font("Arial", Font.BOLD, 20));
        buttonSaveFile.setHorizontalTextPosition(buttonSaveFile.CENTER);
        buttonSaveFile.setVerticalTextPosition(buttonSaveFile.BOTTOM);
        buttonSaveFile.setFocusable(false);
        buttonSaveFile.setBackground(new Color(0x9BA0AA));
        buttonSaveFile.setOpaque(true);
        buttonSaveFile.setBorderPainted(false);
        buttonSaveFile.setToolTipText("Download Text File");

//buttonDownloadFile____________________________________________________________________________________________________

        //ImageIcon OpenFile = new ImageIcon("folder-open.png");
        buttonOpenFile.setBounds(882, 285, 105, 255);
        buttonOpenFile.setText("Open\nFile");
        buttonOpenFile.setFont(new Font("Arial", Font.BOLD, 20));
        //buttonOpenFile.setIcon(OpenFile);
        buttonOpenFile.setHorizontalTextPosition(buttonOpenFile.CENTER);
        buttonOpenFile.setVerticalTextPosition(buttonOpenFile.BOTTOM);
        buttonOpenFile.setFocusable(false);
        buttonOpenFile.setBackground(new Color(0x9BA0AA));
        buttonOpenFile.setOpaque(true);
        buttonOpenFile.setBorderPainted(false);
        buttonOpenFile.setToolTipText("Open Text File");

//buttonPlay_ActionListener_____________________________________________________________________________________________

        buttonPlay.addActionListener(new ActionListener() {
            
          
            @Override
            public void actionPerformed(ActionEvent e) {

             jTextArea.append("\n_________________________________________________________________________\n" +
                     "StartTest");
           
            }
        });

//buttonStop_ActionListener_____________________________________________________________________________________________

        buttonStop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                jTextArea.append("\n_________________________________________________________________________\n" +
                        "StopTest");
            }
        });

//buttonInterface_ActionListener________________________________________________________________________________________

        buttonInterfaces.addActionListener(new ActionListener() {
            
          
          
            jpcap.NetworkInterface [] array ;
            @Override
            public void actionPerformed(ActionEvent e) {
                
             
                array  = JpcapCaptor.getDeviceList();
                jTextArea.append("Available Interfaces: ");

         for (int i=1;  i<array.length ; i++)
                   
              {
                   jTextArea.append("\n\n_____________Interface "+ i + "____________________________________________\n");
                   jTextArea.append("\nName: " + array[i].name);
                   jTextArea.append("\ndatalink_name: " + array[i].datalink_name);
                   jTextArea.append("\nDescription: " + array[i].description);   
                   jTextArea.append("\ndatalink_description :" + array[i].datalink_description);
                   
                   
                   byte [] R = array[i].mac_address;
                   jTextArea.append("\nmac_address: ");
                    for(int B = 0; B < R.length; B++)
                    { jTextArea.append(Integer.toHexString(R[B] & 0xff ));
                            if(B < R.length-1){ jTextArea.append(":");}
                            }
                    
                    jpcap.NetworkInterfaceAddress [] INT = array[i].addresses;
                     
                   // for(int A = 0; A <= array.length; A++)
                   // { jTextArea.append(Integer.toHexString(R[A] & 0xff )+ ":");}
                    jTextArea.append("\nIP Adress: " + INT[0].address);
                    jTextArea.append("\nSubnet Mask: " + INT[0].subnet);
                    jTextArea.append("\nBroadcast: " + INT[0].broadcast);
                        
              }

                }
        });

//buttonClen_ActionListener_____________________________________________________________________________________________

        buttonClean.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                jTextArea.setText("");
            }
        });

//buttonSaveFile_ActionListener_____________________________________________________________________________________

        buttonSaveFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            //Saving_Data
                String data = jTextArea.getText();
                SaveFile saveFile = new SaveFile(data);
                saveFile.saving();
                
            }
        });

//buttonOpenFile_ActionListener_________________________________________________________________________________________

        buttonOpenFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //Open_Data
                OpenFile openFile = new OpenFile();
                openFile.opening();
            }
        });

//______________________________________________________________________________________________________________________




    }
}

