package javasniffer;
import jpcap.JpcapCaptor;




public class ListNetworkInterface {
    
    
    ListNetworkInterface() {}
    
      jpcap.NetworkInterface [] array ;
     
     
    public void getNetworkInterface() {
    
        MainFrame mainFrame = new MainFrame();
        
    
                array  = JpcapCaptor.getDeviceList();
   
                mainFrame.jTextArea.append("Available Interfaces: ");

         for (int i=1;  i<array.length ; i++)
                   
              {
                   mainFrame.jTextArea.append("\n\n_____________Interface "+ i + "____________________________________________\n");
                   mainFrame.jTextArea.append("\nName: " + array[i].name);
                   mainFrame.jTextArea.append("\ndatalink_name: " + array[i].datalink_name);
                   mainFrame.jTextArea.append("\nDescription: " + array[i].description);   
                  mainFrame.jTextArea.append("\ndatalink_description :" + array[i].datalink_description);
                   
                   
                   byte [] R = array[i].mac_address;
                   mainFrame.jTextArea.append("\nmac_address: ");
                    for(int B = 0; B < R.length; B++)
                    { mainFrame.jTextArea.append(Integer.toHexString(R[B] & 0xff ));
                            if(B < R.length-1){ mainFrame.jTextArea.append(":");}
                            }
                    
                    jpcap.NetworkInterfaceAddress [] INT = array[i].addresses;
                     
                   // for(int A = 0; A <= array.length; A++)
                   // { jTextArea.append(Integer.toHexString(R[A] & 0xff )+ ":");}
                    mainFrame.jTextArea.append("\nIP Adress: " + INT[0].address);
                    mainFrame.jTextArea.append("\nSubnet Mask: " + INT[0].subnet);
                    mainFrame.jTextArea.append("\nBroadcast: " + INT[0].broadcast);
                        
              }
         
    }
    
}